package com.cg.ems.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ems.beans.Employee;
import com.cg.ems.beans.User;

public class TestEmpDemo {

	public static void main(String[] args) 
	{
	    ApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml");
	    
	    Employee e1 = (Employee)ctx.getBean("emp1");	    
	    System.out.println("Emp Info : "+e1);
	    
	    System.out.println("HashCode e1 : "+e1.hashCode());
	    
	    Employee e2 = (Employee)ctx.getBean("emp1");	    
	    System.out.println("Emp Info : "+e2);
	    
	    System.out.println("HashCode e2 : "+e2.hashCode());
	    
	    System.out.println("----------------------------------------------------");
	    
	    User u1 = (User)ctx.getBean("user1");
	    System.out.println("User Credentials : "+u1);

	}

}
