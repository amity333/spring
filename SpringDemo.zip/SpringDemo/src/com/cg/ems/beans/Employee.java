package com.cg.ems.beans;

import java.util.ArrayList;

public class Employee 
{
	private int empId;
	private String empName;
	private float empsal;
	private Department empDemp;
	private ArrayList<String> empWorkLoc;
	
	public Employee()
	{
		
	}
	
	public ArrayList<String> getEmpWorkLoc() {
		return empWorkLoc;
	}

	public void setEmpWorkLoc(ArrayList<String> empWorkLoc) {
		this.empWorkLoc = empWorkLoc;
	}

	
	public int getEmpId() {
		return empId;
	}
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	public float getEmpsal() {
		return empsal;
	}
	
	public void setEmpsal(float empsal) {
		this.empsal = empsal;
	}
	

	public Department getEmpDemp() {
		return empDemp;
	}

	public void setEmpDemp(Department empDemp) {
		this.empDemp = empDemp;
	}

	@Override
	public String toString() {
		return "Employee1 [empId=" + empId + ", empName=" + empName + ", empsal=" + empsal + ", empDemp=" + empDemp
				+ ", empWorkLoc=" + empWorkLoc + "]";
	}

	public Employee(int empId, String empName, float empsal, Department empDemp) 
	{
		super();
		this.empId = empId;
		this.empName = empName;
		this.empsal = empsal;
		this.empDemp = empDemp;
		
	}
	
	
	
	
	

}
