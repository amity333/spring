package com.cg.ums.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ums.dao.LoginRepository;
import com.cg.ums.dto.Login;

@Service
@Transactional
public class LoginServiceImpl implements ILoginService{

	@Autowired
	LoginRepository logDao;
	
	@Override
	public ArrayList<Login> getAllUsers() {
		
		return logDao.getAllUsers();
	}

	@Override
	public Login addUser(Login log) {
		
		return logDao.save(log);   // This will add Data to table
	}

	@Override
	public Login getUserByUserName(String unm) {
		
		return logDao.getUserByUserName(unm);
	}

	@Override
	public void deleteByUserName(String unm) {
		logDao.deleteById(unm);
	}

	@Override
	public void updatePwd(String unm, String pwd) {
		logDao.updatePwd(unm, pwd);
		
	}


	
	
	

}
