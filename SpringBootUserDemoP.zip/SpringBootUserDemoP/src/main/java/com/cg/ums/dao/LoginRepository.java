package com.cg.ums.dao;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ums.dto.Login;

@Repository("loginJpaDao")
@Transactional
public interface LoginRepository extends JpaRepository<Login, String>{
	
		@Query("SELECT userList FROM Login userList")
		public ArrayList<Login> getAllUsers();
		
		@Query("SELECT log FROM Login log WHERE log.userName=:unm")
		public Login getUserByUserName(String unm);

		@Query("UPDATE Login SET Login.userPass=:pwd WHERE Login.userName=:uname")
		public void updatePwd(@Param("uname") String unm,@Param("pwd") String pwd);
		
		//@Query("DELETE FROM Login log WHERE log.userName=:unm")
		//public Login deleteByUserName(@Param("unm") String unm);
}
