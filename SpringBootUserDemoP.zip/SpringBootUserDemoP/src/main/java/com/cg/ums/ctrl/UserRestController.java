package com.cg.ums.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ums.dto.Login;
import com.cg.ums.service.ILoginService;

@RestController
public class UserRestController {
	@Autowired
	ILoginService logSer;
	
	@RequestMapping(value="/showAllUsers",method=RequestMethod.GET, headers="Accept=application/json")
	public ArrayList<Login> showAllUsers(){
		
		System.out.println("----Inside UserController-----");
		return logSer.getAllUsers();
	}
	
	@PostMapping(value="/addUser", consumes=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json", produces=MediaType.APPLICATION_JSON_VALUE)
	public Login createUser(@RequestBody Login log) {
		logSer.addUser(log);
		Login lgg = logSer.getUserByUserName(log.getUserName());
		return lgg;
	}
	
	@PostMapping(value="/deleteUser", consumes=MediaType.TEXT_PLAIN_VALUE, headers="Accept=application/json")
	public ArrayList<Login> deleteUser(@RequestBody String unm) {
		logSer.deleteByUserName(unm);
		return logSer.getAllUsers();
	}
	
	@PostMapping(value="/updatePwd", consumes=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ArrayList<Login> updPwd(@RequestBody Login log) {
		logSer.updatePwd(log.getUserName(),log.getUserPass());
		return logSer.getAllUsers();
	}
}
