package com.cg.ems.service;

import com.cg.ems.dto.Login;

public interface LoginService
{
	public Login getUserById(String unm);
	public boolean validateUser(Login user);
    
}
