package com.cg.ems.dao;

import com.cg.ems.dto.Login;

public interface LoginDao 
{
	public Login getUserById(String unm);

}
