package com.cg.ems.dao;

import org.springframework.stereotype.Component;

import com.cg.ems.dto.Login;

@Component
public class LoginDaoImpl implements LoginDao
{

	public Login getUserById(String unm) {
		Login userDetails = new Login("amit@gmail.com","amit");
		return userDetails;
	}
	

}
